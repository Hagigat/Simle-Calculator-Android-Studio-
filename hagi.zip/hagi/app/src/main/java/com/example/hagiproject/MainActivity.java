package com.example.hagiproject;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText editTextName, editTextNum1, editTextNum2;
    private TextView labelName, labelSum;
    private Database dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new Database(this);

        editTextName = findViewById(R.id.editTextName);
        editTextNum1 = findViewById(R.id.editTextNum1);
        editTextNum2 = findViewById(R.id.editTextNum2);

        Button btnAdd = findViewById(R.id.btnAdd);
        Button btnDisplay = findViewById(R.id.btnDisplay);
        Button btnClear = findViewById(R.id.btnClear);

        labelName = findViewById(R.id.labelName);
        labelSum = findViewById(R.id.labelSum);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addEntryToDatabase();
            }
        });

        btnDisplay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                displayValues();
            }
        });

        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clearValues();
            }
        });
    }

    @SuppressLint("SetTextI18n")
    private void addEntryToDatabase() {
        String name = editTextName.getText().toString();
        String num1 = editTextNum1.getText().toString();
        String num2 = editTextNum2.getText().toString();
        double sum = calculateSum(num1, num2);
        saveEntryToDatabase(name, sum);
        labelName.setText("Name: " + name);
        labelSum.setText("Sum: " + calculateSum(num1, num2));


    }

    private void saveEntryToDatabase(String name, double sum) {
        ContentValues values = new ContentValues();
        values.put(Database.COLUMN_ENTRY, "Name: " + name + ", Sum: " + sum);
        SQLiteDatabase database = dbHelper.getWritableDatabase();
        database.insert(Database.TABLE_ENTRIES, null, values);
        database.close();
    }

    private void displayValues() {
        Intent intent = new Intent(this, List.class);
        startActivity(intent);
    }

    private double calculateSum(String num1, String num2) {
        try {
            return Double.parseDouble(num1) + Double.parseDouble(num2);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    @SuppressLint("SetTextI18n")
    private void clearValues() {
        editTextName.setText("");
        editTextNum1.setText("");
        editTextNum2.setText("");
        labelName.setText("Name: ");
        labelSum.setText("Sum: ");

        clearEntriesFromDatabase();
        Toast.makeText(this, "List cleared", Toast.LENGTH_SHORT).show();
    }

    private void clearEntriesFromDatabase() {
        SQLiteDatabase database = dbHelper.getWritableDatabase();
        database.delete(Database.TABLE_ENTRIES, null, null);
        database.close();
    }

    @Override
    protected void onStop() {
        super.onStop();
        Notification.showStopNotification(this);
    }
}
