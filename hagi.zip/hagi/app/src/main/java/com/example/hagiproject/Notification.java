package com.example.hagiproject;//

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;

public class Notification {

    private static final String CHANNEL_ID = "stop_counter_channel";
    private static final String CHANNEL_NAME = "Stop Counter Channel";
    private static int stopCounter = 0;

    public static void showStopNotification(Context context) {
        stopCounter++;
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            notificationManager.createNotificationChannel(channel);
        }

        android.app.Notification notification = new android.app.Notification.Builder(context, CHANNEL_ID)
                .setContentTitle("Activity Stopped")
                .setContentText("Stops so far: " + stopCounter)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .build();

        notificationManager.notify(1, notification);
    }
}
