package com.example.hagiproject;// src/main/java/com.yourpackage/ListActivity.java

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class List extends AppCompatActivity {

    private Database dbHelper;
    private SQLiteDatabase database;
    private ArrayList<String> entryList;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        dbHelper = new Database(this);

        try {
            database = dbHelper.getReadableDatabase();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        ListView listView = findViewById(R.id.listView);

        entryList = getEntryListFromDatabase();
        adapter = new ArrayAdapter<>(this, R.layout.list, R.id.textViewListItem, entryList);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                String clickedEntry = (String) adapterView.getItemAtPosition(position);
                displayEntryValues(clickedEntry);
            }
        });
    }

    private ArrayList<String> getEntryListFromDatabase() {
        ArrayList<String> entries = new ArrayList<>();

        Cursor cursor = database.query(Database.TABLE_ENTRIES,
                new String[]{Database.COLUMN_ENTRY},
                null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String entry = cursor.getString(cursor.getColumnIndex(Database.COLUMN_ENTRY));
                entries.add(entry);
            } while (cursor.moveToNext());
            cursor.close();
        }
        return entries;
    }

    private void displayEntryValues(String entry) {
        String[] values = entry.split(", ");
        String name = values[0].substring("Name: ".length());
        String sum = values[1].substring("Sum: ".length());
        String toastMessage = "Name: " + name + "\nSum: " + sum;
        Toast.makeText(this, toastMessage, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onStop() {
        super.onStop();
        Notification.showStopNotification(this);
        Log.d("Lifecycle", "onStop called");
    }
}
